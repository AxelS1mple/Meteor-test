Package["core-runtime"].queue("typescript",function () {


/* Exports */
return {

}});
