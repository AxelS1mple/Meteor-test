Package["core-runtime"].queue("standard-minifier-js",function () {


/* Exports */
return {

}});
